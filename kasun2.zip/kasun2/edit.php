




<html>
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/bootstrap.min.css" rel="stylesheet">

  <script src="js/bootstrap.min.js"></script>
</head>
<body>
    
    <?php


$error=false;
if (isset($_POST['btn_sub'])) {
$id=$_POST['id'];
$title=$_POST['title'];
$contact=$_POST['contact'];
$designation=$_POST['designation'];
$tel=$_POST['tel'];
$mobile=$_POST['mobile'];
$fax=$_POST['fax'];

	
if(is_numeric($designation))
{
	echo"<script>alert('Errorwwwww')</script>";
}
if(is_string($mobile))
{
	"<script>alert('pls enternumber to mobile')</script>";
}
include 'connection.php';
$sql="UPDATE company SET Title='$title',Contact='$contact',Designation='$designation',Tel='$tel' WHERE Customer_id='$id' ";

if ($conn->query($sql)===TRUE)
{
	echo "<script>alert('Edited')</script>";

}
else
{echo "<script>alert('Error')</script>";}

$conn->close();

}
?>
<div class="container">       
<nav calass="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Cyber Consepts</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="insert.php">Insert</a></li>
      <li><a href="edit.php">Edit</a></li>
      <li><a href="delete.php">Delete</a></li>
  
    </ul>
  </div>
</nav>

    
    
    
    
        <form name="f1" action="edit.php" method="post" class="form-horizontal">
    <!--panel for the form (form size )-->
			<div class="row">
				<div class="col-md-8 col-sm-12 col-xs-12">
					<div class="panel panel-info">
						<div class="panel-heading">
                         UPDATE CUSTOMER
						</div>
             
						<div class="panel-body">
                            <!--end upper tags-->            
               
                                        
                                        
							<div class="form-group">
								<lable class="control-label col-sm-2" >Customer Id :</lable>
								<div class="col-sm-10">
									<input class="form-control" required="required" type="number"  name="id" id="id" class="form-control"  value="<?php if ($error) echo $id; ?>">
									<span class="text_danger"><?php if (isset($nor)) echo $nor; ?></span>
								</div>
							</div>
							<div class="form-group">
								<lable class="control-label col-sm-2">Title :</lable>
								<div class="col-sm-10">
									<input class="form-control" type="text" name="title" id="title" class="form-control"  value="<?php if ($error) echo $age; ?>">
									<span class="text_danger"><?php if (isset($age_error)) echo $age_error; ?></span>
								</div>
							</div>
							<div class="form-group">
								<lable class="control-label col-sm-2">Contact :</lable>
								<div class="col-sm-10">
									<input class="form-control" name="contact" required="required" type="number"  class="form-control"  value="<?php if ($error) echo $contact; ?>">
									<span class="text_danger"><?php if (isset($conta_error)) echo $conta_error; ?></span>
								</div>
							</div>
					
							<div class="form-group">
							<lable class="control-label col-sm-2">Designation :</lable>
								<div class="col-sm-10">
									<input class="form-control" type="text" name="designation" class="form-control"  value="<?php if ($error) echo $designation; ?>">
									<span class="text_danger"><?php if (isset($de_error)) echo $de_error; ?></span>
								</div>
							</div>
							<div class="form-group">
								<lable class="control-label col-sm-2">Tel :</lable>
								<div class="col-sm-10">
									<input class="form-control" name="tel" required="required" type="number"  class="form-control"  value="<?php if ($error) echo $tel; ?>">
									<span class="text_danger"><?php if (isset($tel_error)) echo $tel_error; ?></span>
								</div>
							</div>
							<div class="form-group">
								<lable class="control-label col-sm-2">Mobile :</lable>
								<div class="col-sm-10">
									<input class="form-control" name="mobile" required="required" type="number"  class="form-control"  value="<?php if ($error) echo $mobile; ?>">
									<span class="text_danger"><?php if (isset($mob_error)) echo $mob_error; ?></span>
								</div>
							</div>
							<div class="form-group">
								<lable class="control-label col-sm-2">Fax :</lable>
								<div class="col-sm-10">
									<input class="form-control" type="text" name="fax" class="form-control" required value="<?php if ($error) echo $fax; ?>">
									<span class="text_danger"><?php if (isset($fax_error)) echo $fax_error; ?></span>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<input type="submit" value="submit" name="btn_sub" class="btn btn-default">
								</div>
							</div>
                <!--panel and re size end tags--> 
						</div>
					</div>
				</div>
			</div><!--end-->
		</form>  
</div>

</body>
</html>