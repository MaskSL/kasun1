
<html>
<head>
<title>Delete</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="css/bootstrap.min.css" rel="stylesheet">

  <script src="js/bootstrap.min.js"></script>


</head>
<body>
    <?php

include 'connection.php';


if($_POST) {
    $id = $_POST['id'];

    $sql = "DELETE FROM company WHERE Customer_id = {$id}";
    if($conn->query($sql) === TRUE) {
       
        
    } else {
        echo "Error updating record : " . $connect->error;
    }

    $conn->close();
}




?>
<div class="container">
    <nav calass="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Cyber Consepts</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="insert.php">Insert</a></li>
      <li><a href="edit.php">Edit</a></li>
      <li><a href="delete.php">Delete</a></li>
	   <li><a href="view.php">table</a></li>
  
  
    </ul>
  </div>
</nav>
    <div class="row">
<div class="col-md-6 col-sm-12 col-xs-12">
<form action="delete.php" method="post">
    <!--panel for the form (form size )-->

<div class="panel panel-info">
<div class="panel-heading">
DELETE CUSTOMER
</div>
             
<div class="panel-body">
                            <!--end upper tags-->       
<div class="form-group">
    
<lable class="control-label col-sm-2">Customer ID</lable>
<div class="col-sm-8">
<input required="required" type="number" name="id" class="form-control" placeholder="Pleas insert your ID"></div>
</div>
<div class="form-group">

<input type="submit" class="btn btn-default" name="delete" value="delete">

</div>
    
</div>
</div>

</form>
</div>
 <div class="col-md-6 col-sm-12 col-xs-12">
     <?php
include 'connection.php';
$sql = "SELECT Customer_Id,Title, Contact ,Designation , Tel ,Mobile , Fax FROM company";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) 
    {
    // output data of each row
	echo "<table border=1><tr><th>Customer id</th><th>Title</th> <th>Contact</th> <th>Designation</th> <th>Tel</th> <th>Mobile</th> <th>Fax</th></tr>";
    
        while($row = mysqli_fetch_assoc($result)) 
                {
                echo "<tr><td>" . $row["Customer_Id"]. "<td> " . $row["Title"]. "</td><td>" . $row["Contact"]. "</td><td>". $row["Designation"]. 
		"</td><td>". $row["Tel"]. "</td><td>". $row["Mobile"]. "</td><td>". $row["Fax"]. "</td></tr>";
                }
    
	echo "</table>";
    }
    else 
    {
    echo "0 results";
    }

mysqli_close($conn);
?>
     
 </div>
</div>

    
    
    
    



</div>
    
</body>
</html>
