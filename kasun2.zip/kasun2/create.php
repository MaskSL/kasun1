<?php

$server="localhost";
$pw="";
$db="cyber";
$username="root";


$id=$_POST['id'];
$title=$_POST['title'];
$contact=$_POST['contact'];
$designation=$_POST['designation'];
$tel=$_POST['tel'];
$mobile=$_POST['mobile'];
$fax=$_POST['fax'];

if($id=="")
{
	echo"empty";
}




$conn=new mysqli($server,$username,$pw,$db);
if($conn->connect_error)
{
	die("connection error".$conn->connect_error);
}
$sql="INSERT INTO company(Customer_id,Title,Contact,Designation,Tel,Mobile,Fax)
VALUES($id,'$title',$contact,'$designation',$tel,$mobile,'$fax')";

if ($conn->query($sql)==TRUE)
{
	echo "inserted";

}
else
{echo"error".$conn->connect_error;}
$conn->close();

?>