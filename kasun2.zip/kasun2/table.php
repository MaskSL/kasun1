<html>
<body>

<?php
include 'connection.php';

$sql = "Customer_Id,Title, Contact ,Designation , Tel ,Mobile , Fax FROM company";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "Customer_id: " . $row["Customer_Id"]. " - Title: " . $row["Title"]. " -Contct" . $row["Contact"]. "Designation". $row["Designation"]. 
		"Tel". $row["Tel"]. "Mobile". $row["Mobile"]. "Fax". $row["Fax"]. "<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
?>

</body>
</html>