-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2017 at 08:51 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cyber`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `Customer_Id` int(10) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Contact` int(11) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Tel` int(11) NOT NULL,
  `Mobile` int(11) NOT NULL,
  `Fax` varchar(20) NOT NULL,
  PRIMARY KEY (`Customer_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Customer_Id`, `Title`, `Contact`, `Designation`, `Tel`, `Mobile`, `Fax`) VALUES
(55, 'kjg', 876, 'kjh', 0, 89, 'jhj'),
(123, 'as', 42351, 'dsaga', 32152, 235135, 'ewqt'),
(312, 'sfdsa', 21213, 'asf', 12312, 2147483647, 'qwqw'),
(764, 'sdg', 124, 'f', 1312, 52145, '2351'),
(1424, '1424', 214, 'asf', 14, 124, 'sgdx'),
(4990, 'ghjg', 8273, 'dgs', 234, 324, 'sdg'),
(12352, 'hbjhb', 546, 'jgj', 654, 876, 'jgk'),
(111111, 'jhgvjkh', 67587, 's,mfn', 124, 214312, 'asfsaf');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
