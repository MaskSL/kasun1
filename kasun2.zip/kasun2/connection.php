<?php
$server="localhost";
$username="root";
$pw="";
$db="cyber";
$conn=new mysqli($server,$username,$pw,$db);
if($conn->connect_error)
{
die("error".$conn->connect_error);
}

?>
